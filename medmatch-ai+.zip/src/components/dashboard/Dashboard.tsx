import React from 'react';
import {
  HeartPulse,
  Pill,
  Clock,
  ScanLine,
  Calendar,
  AlertTriangle,
  Bot,
  FolderLock,
  ChevronRight,
  TrendingUp,
  CheckCircle2,
  ShieldAlert,
  Sparkles,
  Plus,
  Zap,
  ArrowUpRight
} from 'lucide-react';
import {
  UserProfile,
  ActiveMedicine,
  Appointment,
  VaultItem,
  RiskAlert,
  Reminder,
  HealthMetricLog
} from '../../types';
import { LocalHealthAlertsSection } from './LocalHealthAlertsSection';
import { DailyWellnessWisdom } from './DailyWellnessWisdom';
import { AIInsightsWidget } from './AIInsightsWidget';

interface DashboardProps {
  profile: UserProfile;
  activeMedicines: ActiveMedicine[];
  appointments: Appointment[];
  vaultItems: VaultItem[];
  riskAlerts: RiskAlert[];
  reminders: Reminder[];
  metricLogs?: HealthMetricLog[];
  setActiveTab: (tab: string) => void;
  onOpenEmergency: () => void;
  onMarkDoseTaken: (medId: string) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  profile,
  activeMedicines = [],
  appointments = [],
  vaultItems = [],
  riskAlerts = [],
  reminders = [],
  metricLogs = [],
  setActiveTab,
  onOpenEmergency,
  onMarkDoseTaken,
}) => {
  const healthScore = 88;
  const safeActiveMedicines = activeMedicines || [];
  const safeAppointments = appointments || [];
  const safeVaultItems = vaultItems || [];
  const safeRiskAlerts = riskAlerts || [];
  const upcomingApps = safeAppointments.filter((a) => a?.status === 'Upcoming');

  return (
    <div className="space-y-6 sm:space-y-8 min-w-0 w-full">

      {/* Editorial Header Section */}
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-2 border-b border-slate-200/60 dark:border-slate-800 min-w-0">
        <div className="min-w-0">
          <h2 className="text-2xl sm:text-4xl font-light italic font-serif-editorial text-slate-800 dark:text-slate-100 truncate">
            Hello, {profile.name}
          </h2>
          <p className="text-slate-500 dark:text-slate-400 font-medium text-xs sm:text-sm mt-1">
            Your health summary is updated as of {new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
          </p>
        </div>

        <div className="flex items-center gap-3 sm:gap-4 shrink-0">
          <div className="bg-white dark:bg-slate-900 p-3 sm:p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex items-center gap-3 sm:gap-4">
            <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full border-4 border-blue-500 border-t-transparent flex items-center justify-center shrink-0">
              <span className="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-100">{healthScore}</span>
            </div>
            <div>
              <p className="text-[10px] uppercase tracking-wider text-slate-400 font-bold">Health Score</p>
              <p className="text-blue-600 dark:text-blue-400 font-bold leading-none text-xs sm:text-sm">Optimal • Vitals Excellent</p>
            </div>
          </div>

          <button
            onClick={onOpenEmergency}
            className="hidden sm:flex px-4 py-3 bg-rose-600 hover:bg-rose-700 text-white rounded-2xl font-bold text-xs shadow-md shadow-rose-500/20 active:scale-95 transition-all items-center gap-1.5 cursor-pointer"
          >
            <AlertTriangle className="w-4 h-4" />
            <span>SOS ASSIST</span>
          </button>
        </div>
      </header>

      {/* Daily Wellness Wisdom Feature Card */}
      <DailyWellnessWisdom
        profile={profile}
        metricLogs={metricLogs}
        activeMedicines={activeMedicines}
        onNavigateToTab={setActiveTab}
      />

      {/* AI Insights Dashboard Widget */}
      <AIInsightsWidget
        profile={profile}
        metricLogs={metricLogs}
        activeMedicines={activeMedicines}
        onNavigateToTab={setActiveTab}
      />

      {/* Safety & Risk Alerts Banner if any */}
      {safeRiskAlerts.length > 0 && (
        <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-amber-900 dark:text-amber-200 flex items-start gap-3 shadow-xs min-w-0">
          <ShieldAlert className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
          <div className="flex-1 min-w-0">
            <h4 className="font-bold text-xs uppercase tracking-wider text-amber-800 dark:text-amber-300">
              AI Risk Safety Notice Detected
            </h4>
            <p className="text-xs text-amber-700 dark:text-amber-300/90 mt-0.5 break-words">
              {safeRiskAlerts[0].description}
            </p>
          </div>
          <button
            onClick={() => setActiveTab('medicine')}
            className="text-xs font-bold text-amber-800 dark:text-amber-300 hover:underline shrink-0"
          >
            Review Details
          </button>
        </div>
      )}

      {/* Local Health Alerts with Google Search Grounding */}
      <LocalHealthAlertsSection />

      {/* Top Grid: Active Medications & AI Assistant Quick Block */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 min-w-0">

        {/* Active Medications (8 Cols) */}
        <section className="lg:col-span-8 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-4 sm:p-6 flex flex-col justify-between shadow-xs min-w-0">
          <div>
            <div className="flex justify-between items-center mb-4 sm:mb-5">
              <div className="flex items-center gap-2">
                <Pill className="w-5 h-5 text-blue-600" />
                <h3 className="font-bold text-slate-800 dark:text-slate-100 text-base">Active Medications</h3>
              </div>
              <button
                onClick={() => setActiveTab('medicine')}
                className="text-xs text-blue-600 dark:text-blue-400 font-semibold hover:underline flex items-center gap-1 cursor-pointer"
              >
                <span>Manage All</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-3 min-w-0">
              {safeActiveMedicines.map((med, idx) => {
                const initialLetter = med.name.charAt(0).toUpperCase();
                const colors = [
                  'bg-blue-100 text-blue-600 dark:bg-blue-950 dark:text-blue-400',
                  'bg-orange-100 text-orange-600 dark:bg-orange-950 dark:text-orange-400',
                  'bg-teal-100 text-teal-600 dark:bg-teal-950 dark:text-teal-400',
                  'bg-indigo-100 text-indigo-600 dark:bg-indigo-950 dark:text-indigo-400',
                ];
                const badgeColor = colors[idx % colors.length];

                return (
                  <div
                    key={med.id}
                    className="flex items-center p-3 sm:p-3.5 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-100 dark:border-slate-800 min-w-0 gap-3"
                  >
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-xl font-bold italic font-serif-editorial ${badgeColor} shrink-0`}>
                      {initialLetter}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-slate-800 dark:text-slate-100 text-sm truncate">{med.name} {med.dosage}</p>
                      <p className="text-xs text-slate-500 dark:text-slate-400 truncate">{med.frequency} • {med.salt}</p>
                    </div>
                    <div className="text-right flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => onMarkDoseTaken(med.id)}
                        className="px-2.5 sm:px-3 py-1 bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 hover:bg-emerald-200 rounded-full text-[10px] font-bold uppercase transition-colors flex items-center gap-1 cursor-pointer"
                      >
                        <CheckCircle2 className="w-3 h-3" />
                        <span>Log Dose</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* AI Assistant Quick Block (4 Cols) */}
        <section className="lg:col-span-4 bg-slate-900 dark:bg-slate-950 rounded-3xl p-5 sm:p-6 text-white relative overflow-hidden flex flex-col justify-between shadow-xl min-w-0">
          <div className="relative z-10 space-y-4">
            <div>
              <h3 className="font-medium text-slate-400 text-xs uppercase tracking-wider mb-1">AI Health Assistant</h3>
              <p className="text-lg leading-snug font-serif-editorial italic font-light text-slate-100">
                "Ask me anything about your medicines, dosage safety, or symptoms."
              </p>
            </div>

            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => setActiveTab('assistant')}
                className="bg-white/10 hover:bg-white/20 px-3 py-1.5 rounded-xl text-xs backdrop-blur-md transition-all border border-white/10"
              >
                Drug Interactions?
              </button>
              <button
                onClick={() => setActiveTab('assistant')}
                className="bg-white/10 hover:bg-white/20 px-3 py-1.5 rounded-xl text-xs backdrop-blur-md transition-all border border-white/10"
              >
                Side Effects?
              </button>
            </div>

            <div className="pt-2">
              <button
                onClick={() => setActiveTab('assistant')}
                className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl transition-all shadow-md flex items-center justify-center gap-2"
              >
                <Bot className="w-4 h-4" />
                <span>Open Multimodal Assistant</span>
              </button>
            </div>
          </div>
          <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-blue-600/20 blur-3xl rounded-full pointer-events-none"></div>
        </section>

      </div>

      {/* Bottom Grid: Vault & Prescription Scanner */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 min-w-0">

        {/* Medical Vault Quick Access (4 Cols) */}
        <section className="lg:col-span-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 sm:p-6 flex flex-col justify-between shadow-xs min-w-0">
          <div>
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold text-slate-800 dark:text-slate-100 text-base">Medical Vault</h3>
              <button
                onClick={() => setActiveTab('vault')}
                className="text-xs text-blue-600 dark:text-blue-400 font-semibold hover:underline"
              >
                View All ({safeVaultItems.length})
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div
                onClick={() => setActiveTab('vault')}
                className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-100 dark:border-slate-800 text-center hover:bg-blue-50 dark:hover:bg-slate-800 transition-colors cursor-pointer group"
              >
                <div className="w-8 h-8 bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-xl flex items-center justify-center mx-auto mb-2 text-blue-600 dark:text-blue-400 group-hover:border-blue-300">
                  📄
                </div>
                <p className="text-[11px] font-bold text-slate-700 dark:text-slate-200">Lab Reports</p>
                <p className="text-[9px] text-slate-400 uppercase font-bold">12 Files</p>
              </div>

              <div
                onClick={() => setActiveTab('vault')}
                className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-100 dark:border-slate-800 text-center hover:bg-blue-50 dark:hover:bg-slate-800 transition-colors cursor-pointer group"
              >
                <div className="w-8 h-8 bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-xl flex items-center justify-center mx-auto mb-2 text-blue-600 dark:text-blue-400 group-hover:border-blue-300">
                  💊
                </div>
                <p className="text-[11px] font-bold text-slate-700 dark:text-slate-200">Prescriptions</p>
                <p className="text-[9px] text-slate-400 uppercase font-bold">8 Files</p>
              </div>

              <div
                onClick={() => setActiveTab('vault')}
                className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-100 dark:border-slate-800 text-center hover:bg-blue-50 dark:hover:bg-slate-800 transition-colors cursor-pointer group"
              >
                <div className="w-8 h-8 bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-xl flex items-center justify-center mx-auto mb-2 text-blue-600 dark:text-blue-400 group-hover:border-blue-300">
                  🩻
                </div>
                <p className="text-[11px] font-bold text-slate-700 dark:text-slate-200">Scans / MRI</p>
                <p className="text-[9px] text-slate-400 uppercase font-bold">4 Files</p>
              </div>

              <div
                onClick={() => setActiveTab('vault')}
                className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-100 dark:border-slate-800 text-center hover:bg-blue-50 dark:hover:bg-slate-800 transition-colors cursor-pointer group"
              >
                <div className="w-8 h-8 bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-xl flex items-center justify-center mx-auto mb-2 text-blue-600 dark:text-blue-400 group-hover:border-blue-300">
                  💉
                </div>
                <p className="text-[11px] font-bold text-slate-700 dark:text-slate-200">Vaccines</p>
                <p className="text-[9px] text-slate-400 uppercase font-bold">3 Files</p>
              </div>
            </div>
          </div>
        </section>

        {/* AI Prescription Scanner Banner (8 Cols) */}
        <section className="lg:col-span-8 bg-gradient-to-r from-blue-600 to-indigo-700 rounded-3xl p-6 sm:p-8 flex flex-col md:flex-row text-white overflow-hidden relative shadow-lg">
          <div className="flex-1 flex flex-col justify-between space-y-4 relative z-10">
            <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center">
              <ScanLine className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="text-2xl font-bold mb-2 font-serif-editorial italic font-light text-white">
                Scan New Prescription
              </h3>
              <p className="text-blue-100 text-xs sm:text-sm max-w-md leading-relaxed">
                Upload a photo of your medical report or handwritten doctor's prescription to automatically extract medicine details, salt composition, and dosage timeline.
              </p>
            </div>
            <div className="flex flex-wrap gap-3 pt-2">
              <button
                onClick={() => setActiveTab('scanner')}
                className="bg-white text-blue-700 hover:bg-slate-100 px-5 py-2.5 rounded-xl font-bold text-xs shadow-md transition-all flex items-center gap-2"
              >
                <ScanLine className="w-4 h-4 text-blue-600" />
                <span>Upload & Analyze File</span>
              </button>
            </div>
          </div>

          <div className="mt-6 md:mt-0 flex-1 flex justify-center items-center relative z-10">
            <div className="w-48 h-48 sm:w-56 sm:h-56 bg-white/10 border-2 border-dashed border-white/40 rounded-2xl flex items-center justify-center p-4 text-center">
              <div>
                <ScanLine className="w-10 h-10 mx-auto mb-2 text-white/70 animate-pulse" />
                <p className="text-xs uppercase tracking-widest font-bold text-white/80">AI OCR Analysis</p>
                <p className="text-[10px] text-blue-200 mt-1">Extracts active salt & dosage</p>
              </div>
            </div>
          </div>
        </section>

      </div>

      {/* Editorial Bottom Vitals Ticker Banner */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-4 shadow-xs">
        <div className="flex flex-wrap items-center gap-6 text-xs">
          <div className="flex items-center gap-2">
            <span className="text-blue-600 font-bold">BP</span>
            <span className="text-slate-800 dark:text-slate-100 font-bold italic font-serif-editorial">118/76 mmHg</span>
            <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold uppercase bg-emerald-50 dark:bg-emerald-950 px-2 py-0.5 rounded-full">Normal</span>
          </div>
          <div className="hidden sm:block h-4 w-px bg-slate-200 dark:bg-slate-800"></div>
          <div className="flex items-center gap-2">
            <span className="text-blue-600 font-bold">Sugar</span>
            <span className="text-slate-800 dark:text-slate-100 font-bold italic font-serif-editorial">92 mg/dL</span>
            <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold uppercase bg-emerald-50 dark:bg-emerald-950 px-2 py-0.5 rounded-full">Good</span>
          </div>
          <div className="hidden sm:block h-4 w-px bg-slate-200 dark:bg-slate-800"></div>
          <div className="flex items-center gap-2">
            <span className="text-blue-600 font-bold">Weight</span>
            <span className="text-slate-800 dark:text-slate-100 font-bold italic font-serif-editorial">74.2 kg</span>
            <span className="text-[10px] text-amber-600 dark:text-amber-400 font-bold uppercase bg-amber-50 dark:bg-amber-950 px-2 py-0.5 rounded-full">+0.5 kg</span>
          </div>
        </div>
        <p className="text-xs text-slate-400 font-medium italic font-serif-editorial">
          All health records encrypted with AES-256 for lifetime privacy.
        </p>
      </div>

    </div>
  );
};
